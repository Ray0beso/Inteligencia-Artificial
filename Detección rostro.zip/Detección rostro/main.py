
import cv2
import numpy as np
import os
import tensorflow as tf
from tensorflow.keras.models import load_model

# Rutas de directorios
DIR_ENTRENAMIENTO = 'entrenamiento'
DIR_PRUEBA = 'prueba'
DIR_RESULTS = 'results'

# Cargar modelo de detección de rostros de OpenCV
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# Cargar modelo de embedding de rostros
facenet = load_model('facenet_keras.h5')

# Función para cargar una imagen
def load_image(dir, name):
    return cv2.cvtColor(cv2.imread(os.path.join(dir, name)), cv2.COLOR_BGR2RGB)

# Función para dibujar un rectángulo alrededor del rostro detectado
def draw_box(image, box, color, line_width=6):
    if box == []:
        return image
    else:
        cv2.rectangle(image, (box[0], box[2]), (box[1], box[3]), color, line_width)
    return image

# Función para extraer los rostros de una imagen
def extract_faces(image, bboxes, new_size=(160, 160)):
    cropped_faces = []
    for box in bboxes:
        left, right, top, bottom = box
        face = image[top:bottom, left:right]
        cropped_faces.append(cv2.resize(face, dsize=new_size))
    return cropped_faces

# Función para calcular el embedding de un rostro
def compute_embedding(model, face):
    face = face.astype('float32')
    
    mean, std = face.mean(), face.std()
    face = (face - mean) / std
    
    face = np.expand_dims(face, axis=0)
    
    embedding = model.predict(face)
    return embedding

# Función para comparar los embeddings de los rostros
def compare_faces(embs_ref, emb_desc, umbral=11):
    distancias = []
    for emb_ref in embs_ref:
        distancias.append(np.linalg.norm(emb_ref - emb_desc))
    distancias = np.array(distancias)
    return distancias, list(distancias <= umbral)

# Procesar rostros conocidos
known_embeddings = []
print('Procesando rostros conocidos...')
for name in os.listdir(DIR_ENTRENAMIENTO):
    if name.endswith('.jpg'):
        print(f'   {name}')
        image = load_image(DIR_ENTRENAMIENTO, name)
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.1, 4)
        if len(faces) > 0:
            face = extract_faces(image, faces)[0]
            known_embeddings.append(compute_embedding(facenet, face))

# Procesar imágenes desconocidas
print('Procesando imágenes desconocidas...')
for name in os.listdir(DIR_PRUEBA):
    if name.endswith('.jpg'):
        print(f'   {name}')
        image = load_image(DIR_PRUEBA, name)
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.1, 4)
        img_with_boxes = image.copy()
        for face, box in zip(extract_faces(image, faces), faces):
            emb = compute_embedding(facenet, face)
            _, reconocimiento = compare_faces(known_embeddings, emb)
            if any(reconocimiento):
                img_with_boxes = draw_box(img_with_boxes, box, (0, 255, 0))
            else:
                img_with_boxes = draw_box(img_with_boxes, box, (255, 0, 0))
        cv2.imwrite(os.path.join(DIR_RESULTS, name), cv2.cvtColor(img_with_boxes, cv2.COLOR_RGB2BGR))

print('¡Fin!')